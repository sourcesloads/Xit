package synthcore.core

import kotlin.math.cos
import kotlin.math.sin

/** Raised when a snapshot cannot be acquired. Never substitute zero data. */
class SourceUnavailable(message: String) : Exception(message)

data class Vec3(val x: Double, val y: Double, val z: Double) {
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    infix fun dot(o: Vec3): Double = x * o.x + y * o.y + z * o.z
    infix fun cross(o: Vec3) = Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
}

/**
 * Conventions: +X forward at yaw=0, +Y left, +Z up, degrees.
 * yaw grows counter-clockwise (towards +Y), pitch positive = up.
 * hfov is horizontal; screen origin is the top-left corner.
 */
data class Camera(
    val position: Vec3,
    val yaw: Double,
    val pitch: Double,
    val hfov: Double,
    val width: Int,
    val height: Int,
    val near: Double = 0.1,
) {
    init {
        require(hfov > 0.0 && hfov < 180.0) { "hfov must be in (0, 180)" }
        require(width > 0 && height > 0) { "viewport must be positive" }
    }

    fun basis(): Triple<Vec3, Vec3, Vec3> {
        val y = Math.toRadians(yaw)
        val p = Math.toRadians(pitch)
        val fwd = Vec3(cos(p) * cos(y), cos(p) * sin(y), sin(p))
        val right = Vec3(sin(y), -cos(y), 0.0)
        return Triple(fwd, right, right cross fwd)
    }
}

data class Entity(
    val entityId: Int,
    val head: Vec3,
    val feet: Vec3,
    val alive: Boolean = true,
    val valid: Boolean = true,
)

data class Snapshot(val tick: Long, val camera: Camera, val entities: List<Entity>)
data class EspBox(val entityId: Int, val left: Double, val top: Double, val right: Double, val bottom: Double)
data class AimCommand(val deltaYaw: Double, val deltaPitch: Double)
