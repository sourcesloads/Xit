package synthcore.core

/** Adapter contracts. A real target adapter would implement these; none ships here. */
interface SnapshotSource {
    /** Return a validated snapshot or throw [SourceUnavailable]. */
    fun read(): Snapshot
}

interface ActionSink {
    fun apply(cmd: AimCommand)
}
