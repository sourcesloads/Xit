package synthcore.core

import kotlin.math.cos
import kotlin.math.sin

/** Synthetic adapters and data. Not a target adapter. */
class StaticSource(private val snap: Snapshot) : SnapshotSource {
    override fun read(): Snapshot = snap
}

class UnavailableSource : SnapshotSource {
    override fun read(): Snapshot = throw SourceUnavailable("synthetic source is unavailable")
}

class RecordingSink : ActionSink {
    val cmds = mutableListOf<AimCommand>()
    override fun apply(cmd: AimCommand) { cmds.add(cmd) }
}

/** Source and sink in one: applying a command rotates the simulated camera. */
class SimulatedWorld(var camera: Camera, var entities: List<Entity>) : SnapshotSource, ActionSink {
    private var tick = 0L

    override fun read(): Snapshot = Snapshot(++tick, camera, entities)

    override fun apply(cmd: AimCommand) {
        camera = camera.copy(
            yaw = Aim.wrapAngle(camera.yaw + cmd.deltaYaw),
            pitch = (camera.pitch + cmd.deltaPitch).coerceIn(-89.0, 89.0),
        )
    }
}

private fun orbit(id: Int, radius: Double, omega: Double, phase: Double, t: Double, alive: Boolean = true): Entity {
    val a = phase + omega * t
    val x = radius * cos(a)
    val y = radius * sin(a)
    return Entity(id, Vec3(x, y, 1.8), Vec3(x, y, 0.0), alive = alive)
}

/** Deterministic moving test objects around the origin; entity 5 is dead, entity 6 is invalid. */
fun demoEntities(t: Double): List<Entity> = listOf(
    orbit(1, 18.0, 0.35, 0.0, t),
    orbit(2, 12.0, -0.50, 2.0, t),
    orbit(3, 25.0, 0.20, 4.0, t),
    orbit(4, 8.0, 0.80, 1.0, t),
    orbit(5, 15.0, 0.30, 3.0, t, alive = false),
    orbit(6, 10.0, 0.40, 5.0, t).copy(valid = false),
)

fun demoCamera(width: Int = 1280, height: Int = 720) =
    Camera(Vec3(0.0, 0.0, 1.7), 0.0, 0.0, 90.0, width, height)
