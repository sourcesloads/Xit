package synthcore.core

import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.sqrt

enum class TargetMode { CROSSHAIR, DISTANCE }

data class AimConfig(
    val maxFov: Double = 10.0,
    val smoothing: Double = 4.0,
    val maxStep: Double = 5.0,
    val mode: TargetMode = TargetMode.CROSSHAIR,
)

object Aim {
    fun wrapAngle(a: Double): Double = ((a + 180.0) % 360.0 + 360.0) % 360.0 - 180.0

    fun anglesTo(origin: Vec3, target: Vec3): Pair<Double, Double> {
        val d = target - origin
        return Pair(
            Math.toDegrees(atan2(d.y, d.x)),
            Math.toDegrees(atan2(d.z, hypot(d.x, d.y))),
        )
    }

    fun angleDelta(cam: Camera, target: Vec3): Pair<Double, Double> {
        val (yaw, pitch) = anglesTo(cam.position, target)
        return Pair(wrapAngle(yaw - cam.yaw), pitch - cam.pitch)
    }

    fun selectTarget(snap: Snapshot, maxFov: Double, mode: TargetMode = TargetMode.CROSSHAIR): Entity? {
        var best: Entity? = null
        var bestKey = Double.POSITIVE_INFINITY
        for (e in snap.entities) {
            if (!(e.valid && e.alive)) continue
            val (dy, dp) = angleDelta(snap.camera, e.head)
            val ang = hypot(dy, dp) // small-angle approximation
            if (ang > maxFov) continue
            val key = when (mode) {
                TargetMode.CROSSHAIR -> ang
                TargetMode.DISTANCE -> {
                    val d = e.head - snap.camera.position
                    sqrt(d dot d)
                }
            }
            if (key < bestKey) {
                best = e
                bestKey = key
            }
        }
        return best
    }

    fun computeAim(snap: Snapshot, cfg: AimConfig = AimConfig()): AimCommand? {
        require(cfg.smoothing >= 1.0 && cfg.maxStep > 0.0) { "smoothing must be >= 1 and maxStep > 0" }
        val t = selectTarget(snap, cfg.maxFov, cfg.mode) ?: return null
        val (dy, dp) = angleDelta(snap.camera, t.head)
        var sy = dy / cfg.smoothing
        var sp = dp / cfg.smoothing
        val mag = hypot(sy, sp)
        if (mag > cfg.maxStep) {
            sy = sy * cfg.maxStep / mag
            sp = sp * cfg.maxStep / mag
        }
        return AimCommand(sy, sp)
    }

    /** One tick: read, compute, apply. [SourceUnavailable] propagates. */
    fun step(source: SnapshotSource, sink: ActionSink, cfg: AimConfig = AimConfig()): AimCommand? {
        val cmd = computeAim(source.read(), cfg)
        if (cmd != null) sink.apply(cmd)
        return cmd
    }
}
