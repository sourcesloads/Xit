package synthcore.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tan

object Esp {
    /** Projects via the camera basis (no matrices). Null for points behind or closer than cam.near. */
    fun worldToScreen(cam: Camera, p: Vec3): Pair<Double, Double>? {
        val (fwd, right, up) = cam.basis()
        val d = p - cam.position
        val depth = d dot fwd
        if (depth <= cam.near) return null
        val focal = (cam.width / 2.0) / tan(Math.toRadians(cam.hfov) / 2.0)
        val sx = cam.width / 2.0 + focal * (d dot right) / depth
        val sy = cam.height / 2.0 - focal * (d dot up) / depth
        return Pair(sx, sy)
    }

    fun buildEsp(snap: Snapshot, aspect: Double = 0.5): List<EspBox> {
        require(aspect > 0.0) { "aspect must be > 0" }
        val out = ArrayList<EspBox>()
        for (e in snap.entities) {
            if (!(e.valid && e.alive)) continue
            val h = worldToScreen(snap.camera, e.head) ?: continue
            val f = worldToScreen(snap.camera, e.feet) ?: continue
            val halfW = abs(f.second - h.second) * aspect / 2.0
            val cx = (h.first + f.first) / 2.0
            out.add(EspBox(e.entityId, cx - halfW, min(h.second, f.second), cx + halfW, max(h.second, f.second)))
        }
        return out
    }
}
