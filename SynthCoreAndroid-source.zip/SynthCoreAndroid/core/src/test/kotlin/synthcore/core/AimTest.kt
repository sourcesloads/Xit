package synthcore.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.hypot
import kotlin.math.sqrt
import kotlin.math.tan

class AimTest {
    private val eps = 1e-6
    private val cam = Camera(Vec3(0.0, 0.0, 0.0), 0.0, 0.0, 90.0, 1000, 500)
    private fun ent(id: Int, x: Double, y: Double, z: Double = 0.0) =
        Entity(id, Vec3(x, y, z), Vec3(x, y, z - 2))

    @Test fun anglesTo() {
        val (yaw, pitch) = Aim.anglesTo(Vec3(0.0, 0.0, 0.0), Vec3(10.0, 10.0, 10 * sqrt(2.0)))
        assertEquals(45.0, yaw, eps)
        assertEquals(45.0, pitch, eps)
    }

    @Test fun wrap() {
        assertEquals(-10.0, Aim.wrapAngle(350.0), eps)
        assertEquals(170.0, Aim.wrapAngle(-190.0), eps)
        assertEquals(-180.0, Aim.wrapAngle(180.0), eps)
    }

    @Test fun shortestPathAcrossWraparound() {
        val c = Camera(Vec3(0.0, 0.0, 0.0), 179.0, 0.0, 90.0, 1000, 500)
        val snap = Snapshot(0, c, listOf(ent(1, -10.0, -0.1745))) // yaw ~ -179
        val cmd = Aim.computeAim(snap, AimConfig(10.0, 1.0, 100.0))!!
        assertEquals(2.0, cmd.deltaYaw, 0.01)
    }

    @Test fun fovExcludesFarTargets() {
        assertNull(Aim.selectTarget(Snapshot(0, cam, listOf(ent(1, 10.0, 10.0))), 10.0))
    }

    @Test fun skipsDeadAndInvalid() {
        val ents = listOf(ent(1, 10.0, 0.0).copy(alive = false), ent(2, 10.0, 0.0).copy(valid = false))
        assertNull(Aim.selectTarget(Snapshot(0, cam, ents), 20.0))
    }

    @Test fun picksClosestToCrosshair() {
        val snap = Snapshot(0, cam, listOf(ent(1, 10.0, 1.0), ent(2, 10.0, 0.2)))
        assertEquals(2, Aim.selectTarget(snap, 20.0)!!.entityId)
    }

    @Test fun distanceModePicksNearest() {
        val snap = Snapshot(0, cam, listOf(ent(1, 30.0, 0.0), ent(2, 5.0, 1.5))) // #2 is ~16.7 deg off
        assertEquals(1, Aim.selectTarget(snap, 20.0, TargetMode.CROSSHAIR)!!.entityId)
        assertEquals(2, Aim.selectTarget(snap, 20.0, TargetMode.DISTANCE)!!.entityId)
    }

    @Test fun smoothingAndClamp() {
        val snap = Snapshot(0, cam, listOf(ent(1, 10.0, 10 * tan(Math.toRadians(8.0)))))
        val cmd = Aim.computeAim(snap, AimConfig(10.0, 2.0, 3.0))!!
        assertEquals(3.0, cmd.deltaYaw, 1e-4) // 4.0 clamped to 3.0
    }

    @Test fun invalidParamsRejected() {
        val snap = Snapshot(0, cam, emptyList())
        assertThrows(IllegalArgumentException::class.java) { Aim.computeAim(snap, AimConfig(smoothing = 0.5)) }
        assertThrows(IllegalArgumentException::class.java) { Aim.computeAim(snap, AimConfig(maxStep = 0.0)) }
    }

    @Test fun stepAppliesCommand() {
        val sink = RecordingSink()
        val cmd = Aim.step(StaticSource(Snapshot(0, cam, listOf(ent(1, 10.0, 0.5)))), sink)
        assertEquals(listOf(cmd), sink.cmds)
    }

    @Test fun noTargetNoAction() {
        val sink = RecordingSink()
        assertNull(Aim.step(StaticSource(Snapshot(0, cam, emptyList())), sink))
        assertTrue(sink.cmds.isEmpty())
    }

    @Test fun unavailableSourceDoesNotFabricateData() {
        val sink = RecordingSink()
        assertThrows(SourceUnavailable::class.java) { Aim.step(UnavailableSource(), sink) }
        assertTrue(sink.cmds.isEmpty())
    }

    @Test fun simulatedWorldConverges() {
        val w = SimulatedWorld(demoCamera(), listOf(Entity(1, Vec3(20.0, 4.0, 1.8), Vec3(20.0, 4.0, 0.0))))
        repeat(60) { Aim.step(w, w, AimConfig(30.0, 4.0, 5.0)) }
        val (dy, dp) = Aim.angleDelta(w.camera, w.entities[0].head)
        assertTrue(hypot(dy, dp) < 0.5)
    }

    @Test fun simulatedWorldClampsPitchAndWrapsYaw() {
        val w = SimulatedWorld(demoCamera(), emptyList())
        w.apply(AimCommand(200.0, 500.0))
        assertEquals(-160.0, w.camera.yaw, eps)
        assertEquals(89.0, w.camera.pitch, eps)
    }

    @Test fun demoEntitiesDeterministicAndOnCircle() {
        assertEquals(demoEntities(1.5), demoEntities(1.5))
        val e = demoEntities(3.0).first { it.entityId == 1 }
        assertEquals(18.0, hypot(e.head.x, e.head.y), 1e-9)
        assertEquals(6, demoEntities(0.0).size)
    }
}
