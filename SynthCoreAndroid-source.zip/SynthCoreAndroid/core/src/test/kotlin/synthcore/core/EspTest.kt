package synthcore.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

class EspTest {
    private val eps = 1e-6
    private val cam = Camera(Vec3(0.0, 0.0, 0.0), 0.0, 0.0, 90.0, 1000, 500)

    @Test fun forwardPointIsScreenCenter() {
        val p = Esp.worldToScreen(cam, Vec3(10.0, 0.0, 0.0))
        assertNotNull(p)
        assertEquals(500.0, p!!.first, eps)
        assertEquals(250.0, p.second, eps)
    }

    @Test fun pointBehindCameraIsNull() {
        assertNull(Esp.worldToScreen(cam, Vec3(-10.0, 0.0, 0.0)))
    }

    @Test fun leftAndUpMapCorrectly() {
        val p = Esp.worldToScreen(cam, Vec3(10.0, 5.0, 5.0))!! // focal = 500
        assertEquals(250.0, p.first, eps)
        assertEquals(0.0, p.second, eps)
    }

    @Test fun yawRotation() {
        val c = Camera(Vec3(0.0, 0.0, 0.0), 90.0, 0.0, 90.0, 1000, 500)
        assertEquals(500.0, Esp.worldToScreen(c, Vec3(0.0, 10.0, 0.0))!!.first, eps)
    }

    @Test fun pitchRotation() {
        val c = Camera(Vec3(0.0, 0.0, 0.0), 0.0, 45.0, 90.0, 1000, 500)
        val p = Esp.worldToScreen(c, Vec3(10.0, 0.0, 10.0))!!
        assertEquals(500.0, p.first, eps)
        assertEquals(250.0, p.second, eps)
    }

    @Test fun invalidCameraRejected() {
        assertThrows(IllegalArgumentException::class.java) { Camera(Vec3(0.0, 0.0, 0.0), 0.0, 0.0, 0.0, 100, 100) }
        assertThrows(IllegalArgumentException::class.java) { Camera(Vec3(0.0, 0.0, 0.0), 0.0, 0.0, 90.0, 0, 100) }
    }

    @Test fun filtersInvalidDeadAndBehind() {
        val ents = listOf(
            Entity(1, Vec3(10.0, 0.0, 1.0), Vec3(10.0, 0.0, -1.0)),
            Entity(2, Vec3(10.0, 0.0, 1.0), Vec3(10.0, 0.0, -1.0), alive = false),
            Entity(3, Vec3(10.0, 0.0, 1.0), Vec3(10.0, 0.0, -1.0), valid = false),
            Entity(4, Vec3(-10.0, 0.0, 1.0), Vec3(-10.0, 0.0, -1.0)),
        )
        val boxes = Esp.buildEsp(Snapshot(0, cam, ents))
        assertEquals(listOf(1), boxes.map { it.entityId })
        val b = boxes[0]
        assertEquals(100.0, b.bottom - b.top, eps)
        assertEquals(500.0, (b.left + b.right) / 2, eps)
        assertEquals(50.0, b.right - b.left, eps)
    }

    @Test fun invalidAspectRejected() {
        assertThrows(IllegalArgumentException::class.java) { Esp.buildEsp(Snapshot(0, cam, emptyList()), 0.0) }
    }
}
