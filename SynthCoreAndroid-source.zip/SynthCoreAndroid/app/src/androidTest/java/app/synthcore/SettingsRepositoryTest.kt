package app.synthcore

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import synthcore.core.TargetMode

@RunWith(AndroidJUnit4::class)
class SettingsRepositoryTest {
    private lateinit var ctx: Context

    @Before fun clean() {
        ctx = ApplicationProvider.getApplicationContext()
        ctx.getSharedPreferences("synthcore_settings", Context.MODE_PRIVATE).edit().clear().commit()
    }

    @Test fun settingsSurviveRecreation() {
        SettingsRepository(ctx).update { it.copy(fov = 33f, aimEnabled = true, targetMode = TargetMode.DISTANCE) }
        val s = SettingsRepository(ctx).settings.value // new instance = "app restart"
        assertEquals(33f, s.fov, 0f)
        assertTrue(s.aimEnabled)
        assertEquals(TargetMode.DISTANCE, s.targetMode)
    }

    @Test fun resetRestoresDefaults() {
        val r = SettingsRepository(ctx)
        r.update { it.copy(fov = 50f) }
        r.reset()
        assertEquals(Settings().fov, SettingsRepository(ctx).settings.value.fov, 0f)
    }

    @Test fun outOfRangeStoredValuesAreClamped() {
        ctx.getSharedPreferences("synthcore_settings", Context.MODE_PRIVATE).edit().putFloat("fov", 999f).commit()
        assertEquals(Settings.FOV_RANGE.endInclusive, SettingsRepository(ctx).settings.value.fov, 0f)
    }
}
