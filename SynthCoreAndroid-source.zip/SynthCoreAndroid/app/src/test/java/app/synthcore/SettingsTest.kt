package app.synthcore

import org.junit.Assert.assertTrue
import org.junit.Test
import synthcore.core.TargetMode

class SettingsTest {
    @Test fun defaultsAreInsideSliderRanges() {
        val d = Settings()
        assertTrue(d.fov in Settings.FOV_RANGE)
        assertTrue(d.smoothing in Settings.SMOOTH_RANGE)
        assertTrue(d.maxStep in Settings.STEP_RANGE)
        assertTrue(d.radarRange in Settings.RADAR_RANGE)
        assertTrue(d.simSpeed in Settings.SPEED_RANGE)
    }

    @Test fun defaultAimIsOffAndTargetModeStable() {
        assertTrue(!Settings().aimEnabled)
        assertTrue(TargetMode.values()[0] == TargetMode.CROSSHAIR) // persisted by ordinal
    }
}
