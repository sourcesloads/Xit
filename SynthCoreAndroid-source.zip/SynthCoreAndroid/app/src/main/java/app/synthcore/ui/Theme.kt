package app.synthcore.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DD0E1),
    onPrimary = Color(0xFF00363D),
    secondary = Color(0xFF80CBC4),
    background = Color(0xFF0B0F14),
    onBackground = Color(0xFFE3E8EE),
    surface = Color(0xFF121821),
    onSurface = Color(0xFFE3E8EE),
    surfaceVariant = Color(0xFF1B2430),
    onSurfaceVariant = Color(0xFFA9B4C2),
    error = Color(0xFFFF6B6B),
)

@Composable
fun SynthCoreTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
