package app.synthcore

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import app.synthcore.ui.AppRoot
import app.synthcore.ui.SynthCoreTheme

class MainActivity : ComponentActivity() {
    private val vm: SimViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SynthCoreTheme { AppRoot(vm) } }
    }

    override fun onStart() {
        super.onStart()
        vm.active = true
    }

    override fun onStop() {
        vm.active = false
        super.onStop()
    }
}
