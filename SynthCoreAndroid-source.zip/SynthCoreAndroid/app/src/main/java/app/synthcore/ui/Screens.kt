package app.synthcore.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PermanentDrawerSheet
import androidx.compose.material3.PermanentNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.synthcore.SimViewModel
import app.synthcore.Settings
import kotlinx.coroutines.launch
import synthcore.core.TargetMode

enum class Screen(val title: String) {
    ESP("ESP"), AIM("Aim"), RADAR("Радар"), SETTINGS("Настройки"), ABOUT("О проекте")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: SimViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.ESP) }
    val wide = LocalConfiguration.current.screenWidthDp >= 840
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val select: (Screen) -> Unit = { screen = it; scope.launch { drawerState.close() } }

    val body: @Composable () -> Unit = {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text(screen.title) },
                    navigationIcon = {
                        if (!wide) {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Меню")
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                )
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) { ScreenHost(screen, vm) }
        }
    }

    if (wide) {
        PermanentNavigationDrawer(
            drawerContent = { PermanentDrawerSheet(Modifier.width(240.dp)) { DrawerItems(screen, select) } },
            content = body,
        )
    } else {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = { ModalDrawerSheet { DrawerItems(screen, select) } },
            content = body,
        )
    }
}

@Composable
private fun DrawerItems(current: Screen, onSelect: (Screen) -> Unit) {
    Text("SynthCore", Modifier.padding(24.dp), style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
    Screen.values().forEach { s ->
        NavigationDrawerItem(
            label = { Text(s.title) },
            selected = s == current,
            onClick = { onSelect(s) },
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
        )
    }
}

@Composable
private fun ScreenHost(screen: Screen, vm: SimViewModel) {
    val st by vm.state.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        when (screen) {
            Screen.ESP -> EspPage(vm, st, s)
            Screen.AIM -> AimPage(vm, st, s)
            Screen.RADAR -> RadarPage(vm, st, s)
            Screen.SETTINGS -> SettingsPage(vm, s)
            Screen.ABOUT -> AboutPage()
        }
    }
}

@Composable
private fun EspPage(vm: SimViewModel, st: app.synthcore.SimState, s: Settings) {
    TwoPane(
        left = { SceneView(st, s, showFov = false, onLook = vm::look) },
        right = {
            SettingsCard {
                SwitchRow("ESP", s.espEnabled) { v -> vm.update { it.copy(espEnabled = v) } }
                SwitchRow("Рамки", s.espBoxes) { v -> vm.update { it.copy(espBoxes = v) } }
                SwitchRow("Подписи (ID, дистанция)", s.espLabels) { v -> vm.update { it.copy(espLabels = v) } }
                Text(
                    "Тестовые объекты: ${st.boxes.size} в кадре. Тяните по сцене, чтобы повернуть камеру.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(onClick = vm::resetView) { Text("Сбросить обзор") }
            }
        },
    )
}

@Composable
private fun AimPage(vm: SimViewModel, st: app.synthcore.SimState, s: Settings) {
    val readout = st.delta?.let {
        "Цель #${st.targetId}   Δyaw=%.1f°   Δpitch=%.1f°".format(it.first, it.second)
    } ?: "Цель вне FOV"
    TwoPane(
        left = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SceneView(st, s, showFov = true, onLook = vm::look)
                Text(readout, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = vm::resetView) { Text("Сбросить обзор") }
            }
        },
        right = {
            SettingsCard {
                SwitchRow("Наведение в тестовом мире", s.aimEnabled) { v -> vm.update { it.copy(aimEnabled = v) } }
                LabeledSlider("FOV", s.fov, Settings.FOV_RANGE, "%.0f°".format(s.fov)) { v -> vm.update { it.copy(fov = v) } }
                LabeledSlider("Smooth", s.smoothing, Settings.SMOOTH_RANGE, "%.1f".format(s.smoothing)) { v -> vm.update { it.copy(smoothing = v) } }
                LabeledSlider("Макс. шаг", s.maxStep, Settings.STEP_RANGE, "%.1f°".format(s.maxStep)) { v -> vm.update { it.copy(maxStep = v) } }
                Text("Выбор цели")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = s.targetMode == TargetMode.CROSSHAIR,
                        onClick = { vm.update { it.copy(targetMode = TargetMode.CROSSHAIR) } },
                        label = { Text("Ближе к прицелу") },
                    )
                    FilterChip(
                        selected = s.targetMode == TargetMode.DISTANCE,
                        onClick = { vm.update { it.copy(targetMode = TargetMode.DISTANCE) } },
                        label = { Text("Ближайший") },
                    )
                }
                SwitchRow("Круг FOV", s.showFovCircle) { v -> vm.update { it.copy(showFovCircle = v) } }
            }
        },
    )
}

@Composable
private fun RadarPage(vm: SimViewModel, st: app.synthcore.SimState, s: Settings) {
    TwoPane(
        left = { RadarView(st, s) },
        right = {
            SettingsCard {
                LabeledSlider("Дальность", s.radarRange, Settings.RADAR_RANGE, "%.0f м".format(s.radarRange)) { v -> vm.update { it.copy(radarRange = v) } }
                SwitchRow("Показывать выбывших", s.radarShowDead) { v -> vm.update { it.copy(radarShowDead = v) } }
                Text("Вид сверху, верх экрана - направление камеры.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
    )
}

@Composable
private fun SettingsPage(vm: SimViewModel, s: Settings) {
    SettingsCard {
        LabeledSlider("Скорость симуляции", s.simSpeed, Settings.SPEED_RANGE, "%.1fx".format(s.simSpeed)) { v -> vm.update { it.copy(simSpeed = v) } }
        Text("Настройки сохраняются автоматически и восстанавливаются после перезапуска.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = vm::resetSettings) { Text("Сбросить настройки") }
    }
}

@Composable
private fun AboutPage() {
    SettingsCard {
        Text("SynthCore для Android", style = MaterialTheme.typography.titleMedium)
        Text("Модуль :core - порт Python-проекта SynthCore без изменения архитектуры: model, contracts (SnapshotSource, ActionSink), Esp, Aim, synthetic.")
        Text("Все данные синтетические. Приложение не имеет разрешений, не читает память других процессов, не рисует поверх других приложений и ничего не делает с играми.")
    }
}
