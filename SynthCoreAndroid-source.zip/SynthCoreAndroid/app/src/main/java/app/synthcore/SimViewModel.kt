package app.synthcore

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import synthcore.core.Aim
import synthcore.core.AimCommand
import synthcore.core.AimConfig
import synthcore.core.Esp
import synthcore.core.EspBox
import synthcore.core.SimulatedWorld
import synthcore.core.Snapshot
import synthcore.core.demoCamera
import synthcore.core.demoEntities

const val VIEW_W = 1280
const val VIEW_H = 720

data class SimState(
    val snapshot: Snapshot,
    val boxes: List<EspBox>,
    val targetId: Int?,
    val cmd: AimCommand?,
    val delta: Pair<Double, Double>?,
)

/** Drives the synthetic world through the unchanged SynthCore contracts. */
class SimViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)
    val settings: StateFlow<Settings> = repo.settings

    private val world = SimulatedWorld(demoCamera(VIEW_W, VIEW_H), demoEntities(0.0))
    private var time = 0.0

    @Volatile var active = true

    private val _state = MutableStateFlow(render(null))
    val state: StateFlow<SimState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            var last = System.nanoTime()
            while (isActive) {
                delay(16)
                val now = System.nanoTime()
                val dt = ((now - last) / 1e9).coerceAtMost(0.1)
                last = now
                if (active) tick(dt)
            }
        }
    }

    fun update(transform: (Settings) -> Settings) = repo.update(transform)
    fun resetSettings() = repo.reset()

    fun look(dx: Float, dy: Float) {
        val c = world.camera
        world.camera = c.copy(
            yaw = Aim.wrapAngle(c.yaw - dx * 0.15),
            pitch = (c.pitch - dy * 0.15).coerceIn(-89.0, 89.0),
        )
    }

    fun resetView() {
        world.camera = world.camera.copy(yaw = 0.0, pitch = 0.0)
    }

    private fun cfg(s: Settings) =
        AimConfig(s.fov.toDouble(), s.smoothing.toDouble(), s.maxStep.toDouble(), s.targetMode)

    private fun tick(dt: Double) {
        val s = settings.value
        time += dt * s.simSpeed
        world.entities = demoEntities(time)
        val cmd = if (s.aimEnabled) Aim.step(world, world, cfg(s)) else null
        _state.value = render(cmd)
    }

    private fun render(cmd: AimCommand?): SimState {
        val s = settings.value
        val snap = world.read()
        val target = Aim.selectTarget(snap, s.fov.toDouble(), s.targetMode)
        return SimState(
            snapshot = snap,
            boxes = Esp.buildEsp(snap),
            targetId = target?.entityId,
            cmd = cmd,
            delta = target?.let { Aim.angleDelta(snap.camera, it.head) },
        )
    }
}
