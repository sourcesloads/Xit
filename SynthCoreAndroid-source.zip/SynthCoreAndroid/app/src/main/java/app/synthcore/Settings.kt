package app.synthcore

import synthcore.core.TargetMode

/** Persisted user settings. Plain data, no Android dependencies. */
data class Settings(
    val espEnabled: Boolean = true,
    val espBoxes: Boolean = true,
    val espLabels: Boolean = true,
    val aimEnabled: Boolean = false,
    val fov: Float = 20f,
    val smoothing: Float = 4f,
    val maxStep: Float = 5f,
    val targetMode: TargetMode = TargetMode.CROSSHAIR,
    val showFovCircle: Boolean = true,
    val radarRange: Float = 30f,
    val radarShowDead: Boolean = false,
    val simSpeed: Float = 1f,
) {
    companion object {
        val FOV_RANGE = 1f..60f
        val SMOOTH_RANGE = 1f..20f
        val STEP_RANGE = 0.5f..20f
        val RADAR_RANGE = 10f..60f
        val SPEED_RANGE = 0.1f..3f
    }
}
