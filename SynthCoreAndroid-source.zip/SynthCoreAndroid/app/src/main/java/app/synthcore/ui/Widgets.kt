package app.synthcore.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.synthcore.SimState
import app.synthcore.Settings
import app.synthcore.VIEW_H
import app.synthcore.VIEW_W
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

private val Grid = Color(0xFF223040)
private val Panel = Color(0xFF0E141B)
private val Good = Color(0xFF66E08A)
private val Dead = Color(0xFF5B6673)

@Composable
fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onChange: (Float) -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(valueText, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

/** Two columns on wide screens (>= 600dp), stacked on narrow ones. */
@Composable
fun TwoPane(left: @Composable () -> Unit, right: @Composable () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        if (maxWidth >= 600.dp) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.weight(1f)) { left() }
                Column(Modifier.weight(1f)) { right() }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                left()
                right()
            }
        }
    }
}

@Composable
fun SceneView(
    state: SimState,
    s: Settings,
    showFov: Boolean,
    modifier: Modifier = Modifier,
    onLook: (Float, Float) -> Unit = { _, _ -> },
) {
    val measurer = rememberTextMeasurer()
    val accent = MaterialTheme.colorScheme.primary
    Canvas(
        modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(12.dp))
            .background(Panel)
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    onLook(drag.x, drag.y)
                }
            },
    ) {
        val sc = size.width / VIEW_W
        val cam = state.snapshot.camera
        val focal = (VIEW_W / 2.0) / tan(Math.toRadians(cam.hfov) / 2.0)
        val horizonY = (((VIEW_H / 2.0) + focal * tan(Math.toRadians(cam.pitch))) * sc).toFloat()
        drawLine(Grid, Offset(0f, horizonY), Offset(size.width, horizonY), 1.dp.toPx())

        val c = Offset(size.width / 2, size.height / 2)
        val arm = 8.dp.toPx()
        drawLine(accent.copy(alpha = 0.6f), Offset(c.x - arm, c.y), Offset(c.x + arm, c.y), 1.5.dp.toPx())
        drawLine(accent.copy(alpha = 0.6f), Offset(c.x, c.y - arm), Offset(c.x, c.y + arm), 1.5.dp.toPx())
        if (showFov && s.showFovCircle) {
            val r = min((focal * tan(Math.toRadians(s.fov.toDouble())) * sc).toFloat(), size.width)
            drawCircle(accent.copy(alpha = 0.5f), radius = r, center = c, style = Stroke(1.dp.toPx()))
        }

        if (!s.espEnabled) {
            drawText(measurer, "ESP выключен", Offset(12.dp.toPx(), 12.dp.toPx()), TextStyle(color = Dead, fontSize = 13.sp))
            return@Canvas
        }
        if (!s.espBoxes) return@Canvas
        for (b in state.boxes) {
            val col = if (b.entityId == state.targetId) accent else Good
            val left = (b.left * sc).toFloat()
            val top = (b.top * sc).toFloat()
            drawRect(
                col,
                topLeft = Offset(left, top),
                size = Size(((b.right - b.left) * sc).toFloat(), ((b.bottom - b.top) * sc).toFloat()),
                style = Stroke(2.dp.toPx()),
            )
            if (s.espLabels) {
                val e = state.snapshot.entities.firstOrNull { it.entityId == b.entityId }
                val dist = e?.let {
                    val d = it.head - cam.position
                    sqrt(d dot d).roundToInt()
                } ?: 0
                drawText(
                    measurer, "#${b.entityId}  ${dist}m",
                    Offset(left, (top - 15.dp.toPx()).coerceAtLeast(0f)),
                    TextStyle(color = col, fontSize = 11.sp),
                )
            }
        }
    }
}

@Composable
fun RadarView(state: SimState, s: Settings, modifier: Modifier = Modifier) {
    val accent = MaterialTheme.colorScheme.primary
    Canvas(modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape).background(Panel)) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2
        for (k in 1..3) drawCircle(Grid, radius = r * k / 3f, center = c, style = Stroke(1.dp.toPx()))
        drawLine(Grid, Offset(c.x, 0f), Offset(c.x, size.height), 1.dp.toPx())
        drawLine(Grid, Offset(0f, c.y), Offset(size.width, c.y), 1.dp.toPx())

        val cam = state.snapshot.camera
        drawArc(
            accent.copy(alpha = 0.15f),
            startAngle = (-90.0 - cam.hfov / 2).toFloat(),
            sweepAngle = cam.hfov.toFloat(),
            useCenter = true,
            topLeft = Offset(c.x - r, c.y - r),
            size = Size(2 * r, 2 * r),
        )

        val yaw = Math.toRadians(cam.yaw)
        val fx = cos(yaw)
        val fy = sin(yaw)
        val range = s.radarRange.toDouble()
        val k = r.toDouble() / range
        for (e in state.snapshot.entities) {
            if (!e.valid) continue
            if (!e.alive && !s.radarShowDead) continue
            val dx = e.feet.x - cam.position.x
            val dy = e.feet.y - cam.position.y
            val ahead = dx * fx + dy * fy
            val left = -dx * fy + dy * fx
            if (hypot(ahead, left) > range) continue
            val col = when {
                !e.alive -> Dead
                e.entityId == state.targetId -> accent
                else -> Good
            }
            drawCircle(col, radius = 4.dp.toPx(), center = Offset((c.x - left * k).toFloat(), (c.y - ahead * k).toFloat()))
        }
        drawCircle(Color.White, radius = 3.dp.toPx(), center = c)
    }
}
