package app.synthcore

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import synthcore.core.TargetMode

class SettingsRepository(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("synthcore_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    fun update(transform: (Settings) -> Settings) {
        val next = transform(_settings.value)
        _settings.value = next
        save(next)
    }

    fun reset() = update { Settings() }

    private fun load(): Settings {
        val d = Settings()
        return Settings(
            espEnabled = prefs.getBoolean("espEnabled", d.espEnabled),
            espBoxes = prefs.getBoolean("espBoxes", d.espBoxes),
            espLabels = prefs.getBoolean("espLabels", d.espLabels),
            aimEnabled = prefs.getBoolean("aimEnabled", d.aimEnabled),
            fov = prefs.getFloat("fov", d.fov).coerceIn(Settings.FOV_RANGE),
            smoothing = prefs.getFloat("smoothing", d.smoothing).coerceIn(Settings.SMOOTH_RANGE),
            maxStep = prefs.getFloat("maxStep", d.maxStep).coerceIn(Settings.STEP_RANGE),
            targetMode = TargetMode.values().getOrElse(prefs.getInt("targetMode", 0)) { TargetMode.CROSSHAIR },
            showFovCircle = prefs.getBoolean("showFovCircle", d.showFovCircle),
            radarRange = prefs.getFloat("radarRange", d.radarRange).coerceIn(Settings.RADAR_RANGE),
            radarShowDead = prefs.getBoolean("radarShowDead", d.radarShowDead),
            simSpeed = prefs.getFloat("simSpeed", d.simSpeed).coerceIn(Settings.SPEED_RANGE),
        )
    }

    private fun save(s: Settings) {
        prefs.edit()
            .putBoolean("espEnabled", s.espEnabled)
            .putBoolean("espBoxes", s.espBoxes)
            .putBoolean("espLabels", s.espLabels)
            .putBoolean("aimEnabled", s.aimEnabled)
            .putFloat("fov", s.fov)
            .putFloat("smoothing", s.smoothing)
            .putFloat("maxStep", s.maxStep)
            .putInt("targetMode", s.targetMode.ordinal)
            .putBoolean("showFovCircle", s.showFovCircle)
            .putFloat("radarRange", s.radarRange)
            .putBoolean("radarShowDead", s.radarShowDead)
            .putFloat("simSpeed", s.simSpeed)
            .apply()
    }
}
