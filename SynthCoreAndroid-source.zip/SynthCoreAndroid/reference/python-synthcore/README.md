# synthcore

Engine-agnostic ESP and aim math core, verified on synthetic data only.
There is no target adapter: `SnapshotSource` and `ActionSink` (src/synthcore/contracts.py) are interfaces,
and the only implementations live in `synthetic.py`. No process access, offsets, or overlay code.

## Layout
- `src/synthcore/model.py` - data types, camera conventions (+X forward, +Y left, +Z up, degrees)
- `src/synthcore/esp.py` - `world_to_screen`, `build_esp`
- `src/synthcore/aim.py` - angle math, target selection, smoothing, `step`
- `src/synthcore/contracts.py` - adapter protocols
- `src/synthcore/synthetic.py` - synthetic source/sink and `SimulatedWorld`
- `src/synthcore/cli.py` - synthetic demo (argparse + logging)
- `tests/` - unit tests

## Run
Requires Python 3.9+, no dependencies.

    python -m unittest discover -s tests -t . -v
    PYTHONPATH=src python -m synthcore --steps 30 -v

On Windows PowerShell: `$env:PYTHONPATH="src"; python -m synthcore --steps 30 -v`

## Notes
- Projection uses the camera basis, not matrices, so multiplication order is not a factor.
- A failed read raises `SourceUnavailable`; the core never substitutes zero data.
