import unittest

from synthcore import Camera, Entity, Snapshot, Vec3, build_esp, world_to_screen

CAM = Camera(Vec3(0, 0, 0), yaw=0, pitch=0, hfov=90, width=1000, height=500)


class ProjectionTests(unittest.TestCase):
    def test_forward_point_is_screen_center(self):
        self.assertEqual(world_to_screen(CAM, Vec3(10, 0, 0)), (500.0, 250.0))

    def test_point_behind_camera_is_none(self):
        self.assertIsNone(world_to_screen(CAM, Vec3(-10, 0, 0)))

    def test_left_and_up(self):
        x, y = world_to_screen(CAM, Vec3(10, 5, 5))  # focal=500
        self.assertAlmostEqual(x, 250.0)
        self.assertAlmostEqual(y, 0.0)

    def test_yaw_rotation(self):
        cam = Camera(Vec3(0, 0, 0), 90, 0, 90, 1000, 500)
        x, _ = world_to_screen(cam, Vec3(0, 10, 0))
        self.assertAlmostEqual(x, 500.0)

    def test_pitch_rotation(self):
        cam = Camera(Vec3(0, 0, 0), 0, 45, 90, 1000, 500)
        x, y = world_to_screen(cam, Vec3(10, 0, 10))
        self.assertAlmostEqual(x, 500.0)
        self.assertAlmostEqual(y, 250.0)

    def test_invalid_camera(self):
        with self.assertRaises(ValueError):
            Camera(Vec3(0, 0, 0), 0, 0, 0, 100, 100)


class EspTests(unittest.TestCase):
    def test_filters_invalid_dead_and_behind(self):
        ents = [
            Entity(1, Vec3(10, 0, 1), Vec3(10, 0, -1)),
            Entity(2, Vec3(10, 0, 1), Vec3(10, 0, -1), alive=False),
            Entity(3, Vec3(10, 0, 1), Vec3(10, 0, -1), valid=False),
            Entity(4, Vec3(-10, 0, 1), Vec3(-10, 0, -1)),
        ]
        boxes = build_esp(Snapshot(0, CAM, ents))
        self.assertEqual([b.entity_id for b in boxes], [1])
        b = boxes[0]
        self.assertAlmostEqual(b.bottom - b.top, 100.0)
        self.assertAlmostEqual((b.left + b.right) / 2, 500.0)
        self.assertAlmostEqual(b.right - b.left, 50.0)

    def test_invalid_aspect(self):
        with self.assertRaises(ValueError):
            build_esp(Snapshot(0, CAM, []), aspect=0)
