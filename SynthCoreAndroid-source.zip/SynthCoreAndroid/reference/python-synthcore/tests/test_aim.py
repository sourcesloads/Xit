import math
import unittest

from synthcore import (AimCommand, Camera, Entity, Snapshot, SourceUnavailable, Vec3,
                       angle_delta, angles_to, compute_aim, select_target, step, wrap_angle)
from synthcore.synthetic import RecordingSink, StaticSource, UnavailableSource, demo_world

CAM = Camera(Vec3(0, 0, 0), yaw=0, pitch=0, hfov=90, width=1000, height=500)


class AimTests(unittest.TestCase):
    def test_angles(self):
        yaw, pitch = angles_to(Vec3(0, 0, 0), Vec3(10, 10, 10 * math.sqrt(2)))
        self.assertAlmostEqual(yaw, 45.0)
        self.assertAlmostEqual(pitch, 45.0)

    def test_wrap(self):
        self.assertAlmostEqual(wrap_angle(350), -10)
        self.assertAlmostEqual(wrap_angle(-190), 170)

    def test_shortest_path_across_wraparound(self):
        cam = Camera(Vec3(0, 0, 0), yaw=179, pitch=0, hfov=90, width=1000, height=500)
        e = Entity(1, Vec3(-10, -0.1745, 0), Vec3(-10, -0.1745, -2))  # yaw ~ -179
        cmd = compute_aim(Snapshot(0, cam, [e]), max_fov=10, smoothing=1, max_step=100)
        self.assertAlmostEqual(cmd.delta_yaw, 2.0, delta=0.01)

    def test_fov_excludes_far_targets(self):
        e = Entity(1, Vec3(10, 10, 0), Vec3(10, 10, -2))
        self.assertIsNone(select_target(Snapshot(0, CAM, [e]), max_fov=10))

    def test_skips_dead_and_invalid(self):
        ents = [Entity(1, Vec3(10, 0, 0), Vec3(10, 0, -2), alive=False),
                Entity(2, Vec3(10, 0, 0), Vec3(10, 0, -2), valid=False)]
        self.assertIsNone(select_target(Snapshot(0, CAM, ents), 20))

    def test_picks_closest_to_crosshair(self):
        a = Entity(1, Vec3(10, 1, 0), Vec3(10, 1, -2))
        b = Entity(2, Vec3(10, 0.2, 0), Vec3(10, 0.2, -2))
        self.assertEqual(select_target(Snapshot(0, CAM, [a, b]), 20).entity_id, 2)

    def test_smoothing_and_clamp(self):
        e = Entity(1, Vec3(10, 10 * math.tan(math.radians(8)), 0), Vec3(10, 1, -2))
        cmd = compute_aim(Snapshot(0, CAM, [e]), max_fov=10, smoothing=2, max_step=3)
        self.assertAlmostEqual(cmd.delta_yaw, 3.0, places=4)  # 4.0 clamped to 3.0

    def test_invalid_params(self):
        with self.assertRaises(ValueError):
            compute_aim(Snapshot(0, CAM, []), smoothing=0.5)
        with self.assertRaises(ValueError):
            compute_aim(Snapshot(0, CAM, []), max_step=0)


class ContractTests(unittest.TestCase):
    def test_step_applies_command(self):
        e = Entity(1, Vec3(10, 0.5, 0), Vec3(10, 0.5, -2))
        sink = RecordingSink()
        cmd = step(StaticSource(Snapshot(0, CAM, [e])), sink)
        self.assertEqual(sink.cmds, [cmd])
        self.assertIsInstance(cmd, AimCommand)

    def test_no_target_no_action(self):
        sink = RecordingSink()
        self.assertIsNone(step(StaticSource(Snapshot(0, CAM, [])), sink))
        self.assertEqual(sink.cmds, [])

    def test_unavailable_source_does_not_fabricate_data(self):
        sink = RecordingSink()
        with self.assertRaises(SourceUnavailable):
            step(UnavailableSource(), sink)
        self.assertEqual(sink.cmds, [])


class ConvergenceTests(unittest.TestCase):
    def test_simulated_world_converges(self):
        w = demo_world()
        for _ in range(60):
            step(w, w, max_fov=30, smoothing=4, max_step=5)
        dy, dp = angle_delta(w.camera, w.entities[0].head)
        self.assertLess(math.hypot(dy, dp), 0.5)
