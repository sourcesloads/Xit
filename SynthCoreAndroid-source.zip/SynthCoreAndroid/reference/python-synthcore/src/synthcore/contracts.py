"""Adapter contracts. A real target adapter would implement these; none ships here."""
from __future__ import annotations

from typing import Protocol

from .model import AimCommand, Snapshot


class SnapshotSource(Protocol):
    def read(self) -> Snapshot:
        """Return a validated snapshot or raise SourceUnavailable."""
        ...


class ActionSink(Protocol):
    def apply(self, cmd: AimCommand) -> None: ...
