"""Aim core: angle math, target selection, smoothing. Output goes through ActionSink."""
from __future__ import annotations

import math
from typing import Optional

from .contracts import ActionSink, SnapshotSource
from .model import AimCommand, Camera, Entity, Snapshot, Vec3


def wrap_angle(a: float) -> float:
    return (a + 180.0) % 360.0 - 180.0


def angles_to(origin: Vec3, target: Vec3) -> tuple[float, float]:
    d = target - origin
    return (math.degrees(math.atan2(d.y, d.x)),
            math.degrees(math.atan2(d.z, math.hypot(d.x, d.y))))


def angle_delta(cam: Camera, target: Vec3) -> tuple[float, float]:
    yaw, pitch = angles_to(cam.position, target)
    return wrap_angle(yaw - cam.yaw), pitch - cam.pitch


def select_target(snap: Snapshot, max_fov: float) -> Optional[Entity]:
    best: Optional[Entity] = None
    best_dist = math.inf
    for e in snap.entities:
        if not (e.valid and e.alive):
            continue
        dy, dp = angle_delta(snap.camera, e.head)
        dist = math.hypot(dy, dp)  # small-angle approximation
        if dist <= max_fov and dist < best_dist:
            best, best_dist = e, dist
    return best


def compute_aim(snap: Snapshot, max_fov: float = 10.0,
                smoothing: float = 4.0, max_step: float = 5.0) -> Optional[AimCommand]:
    if smoothing < 1.0 or max_step <= 0:
        raise ValueError("smoothing must be >= 1 and max_step > 0")
    t = select_target(snap, max_fov)
    if t is None:
        return None
    dy, dp = angle_delta(snap.camera, t.head)
    sy, sp = dy / smoothing, dp / smoothing
    mag = math.hypot(sy, sp)
    if mag > max_step:
        sy, sp = sy * max_step / mag, sp * max_step / mag
    return AimCommand(sy, sp)


def step(source: SnapshotSource, sink: ActionSink, **aim_kwargs) -> Optional[AimCommand]:
    cmd = compute_aim(source.read(), **aim_kwargs)  # SourceUnavailable propagates
    if cmd is not None:
        sink.apply(cmd)
    return cmd
