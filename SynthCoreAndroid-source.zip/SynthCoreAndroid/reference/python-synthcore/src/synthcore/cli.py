"""Synthetic demo: runs the cores against SimulatedWorld only."""
from __future__ import annotations

import argparse
import logging
import sys

from .aim import angle_delta, step
from .esp import build_esp
from .model import SourceUnavailable
from .synthetic import demo_world

log = logging.getLogger("synthcore")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="synthcore", description=__doc__)
    ap.add_argument("--steps", type=int, default=30)
    ap.add_argument("--max-fov", type=float, default=30.0)
    ap.add_argument("--smoothing", type=float, default=4.0)
    ap.add_argument("--max-step", type=float, default=5.0)
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(levelname)s %(message)s")

    world = demo_world()
    try:
        for i in range(args.steps):
            snap = world.read()
            boxes = build_esp(snap)
            cmd = step(world, world, max_fov=args.max_fov,
                       smoothing=args.smoothing, max_step=args.max_step)
            log.debug("step=%d boxes=%d cmd=%s", i, len(boxes), cmd)
            if cmd is None:
                log.info("no target within FOV at step %d", i)
                break
        cam = world.camera
        dy, dp = angle_delta(cam, world.entities[0].head)
        log.info("final yaw=%.2f pitch=%.2f residual=(%.3f, %.3f) esp_boxes=%d",
                 cam.yaw, cam.pitch, dy, dp, len(build_esp(world.read())))
    except SourceUnavailable as exc:
        log.error("source unavailable: %s", exc)
        return 2
    except ValueError as exc:
        log.error("invalid parameter: %s", exc)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
