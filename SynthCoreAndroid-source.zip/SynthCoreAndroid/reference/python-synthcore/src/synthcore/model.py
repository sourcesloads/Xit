"""Plain data types shared by the ESP and aim cores. Engine-agnostic."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence


class SourceUnavailable(Exception):
    """Raised when a snapshot cannot be acquired. Never substitute zero data."""


@dataclass(frozen=True)
class Vec3:
    x: float
    y: float
    z: float

    def __sub__(self, o: "Vec3") -> "Vec3":
        return Vec3(self.x - o.x, self.y - o.y, self.z - o.z)

    def dot(self, o: "Vec3") -> float:
        return self.x * o.x + self.y * o.y + self.z * o.z

    def cross(self, o: "Vec3") -> "Vec3":
        return Vec3(
            self.y * o.z - self.z * o.y,
            self.z * o.x - self.x * o.z,
            self.x * o.y - self.y * o.x,
        )


@dataclass(frozen=True)
class Camera:
    """Conventions: +X forward at yaw=0, +Y left, +Z up. Degrees.
    yaw grows counter-clockwise (towards +Y), pitch positive = up.
    hfov is horizontal; screen origin is the top-left corner."""

    position: Vec3
    yaw: float
    pitch: float
    hfov: float
    width: int
    height: int
    near: float = 0.1

    def __post_init__(self) -> None:
        if not 0.0 < self.hfov < 180.0:
            raise ValueError("hfov must be in (0, 180)")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("viewport must be positive")

    def basis(self) -> tuple[Vec3, Vec3, Vec3]:
        y, p = math.radians(self.yaw), math.radians(self.pitch)
        fwd = Vec3(math.cos(p) * math.cos(y), math.cos(p) * math.sin(y), math.sin(p))
        right = Vec3(math.sin(y), -math.cos(y), 0.0)
        up = right.cross(fwd)
        return fwd, right, up


@dataclass(frozen=True)
class Entity:
    entity_id: int
    head: Vec3
    feet: Vec3
    alive: bool = True
    valid: bool = True


@dataclass(frozen=True)
class Snapshot:
    tick: int
    camera: Camera
    entities: Sequence[Entity]


@dataclass(frozen=True)
class EspBox:
    entity_id: int
    left: float
    top: float
    right: float
    bottom: float


@dataclass(frozen=True)
class AimCommand:
    delta_yaw: float
    delta_pitch: float
