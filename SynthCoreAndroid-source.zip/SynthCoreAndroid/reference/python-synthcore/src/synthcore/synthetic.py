"""Synthetic adapters for tests and the demo. Not a target adapter."""
from __future__ import annotations

from dataclasses import replace
from typing import Sequence

from .model import AimCommand, Camera, Entity, Snapshot, SourceUnavailable, Vec3


class StaticSource:
    def __init__(self, snap: Snapshot) -> None:
        self.snap = snap

    def read(self) -> Snapshot:
        return self.snap


class UnavailableSource:
    def read(self) -> Snapshot:
        raise SourceUnavailable("synthetic source is unavailable")


class RecordingSink:
    def __init__(self) -> None:
        self.cmds: list[AimCommand] = []

    def apply(self, cmd: AimCommand) -> None:
        self.cmds.append(cmd)


class SimulatedWorld:
    """Source and sink in one: applying a command rotates the simulated camera."""

    def __init__(self, camera: Camera, entities: Sequence[Entity]) -> None:
        self.camera = camera
        self.entities = tuple(entities)
        self.tick = 0

    def read(self) -> Snapshot:
        self.tick += 1
        return Snapshot(self.tick, self.camera, self.entities)

    def apply(self, cmd: AimCommand) -> None:
        self.camera = replace(self.camera,
                              yaw=self.camera.yaw + cmd.delta_yaw,
                              pitch=self.camera.pitch + cmd.delta_pitch)


def demo_world() -> SimulatedWorld:
    cam = Camera(Vec3(0, 0, 1.7), yaw=0, pitch=0, hfov=90, width=1280, height=720)
    ents = [
        Entity(1, Vec3(20, 4, 1.8), Vec3(20, 4, 0.0)),
        Entity(2, Vec3(15, -8, 1.8), Vec3(15, -8, 0.0)),
        Entity(3, Vec3(-12, 0, 1.8), Vec3(-12, 0, 0.0)),                  # behind camera
        Entity(4, Vec3(10, 1, 1.8), Vec3(10, 1, 0.0), alive=False),       # dead
    ]
    return SimulatedWorld(cam, ents)
