"""ESP core: projection and box construction."""
from __future__ import annotations

import math
from typing import Optional

from .model import Camera, EspBox, Snapshot, Vec3


def world_to_screen(cam: Camera, p: Vec3) -> Optional[tuple[float, float]]:
    """Project via the camera basis (no matrices, so no multiplication-order ambiguity).
    Returns None for points behind or closer than cam.near."""
    fwd, right, up = cam.basis()
    d = p - cam.position
    depth = d.dot(fwd)
    if depth <= cam.near:
        return None
    focal = (cam.width / 2) / math.tan(math.radians(cam.hfov) / 2)
    sx = cam.width / 2 + focal * d.dot(right) / depth
    sy = cam.height / 2 - focal * d.dot(up) / depth
    return sx, sy


def build_esp(snap: Snapshot, aspect: float = 0.5) -> list[EspBox]:
    if aspect <= 0:
        raise ValueError("aspect must be > 0")
    boxes: list[EspBox] = []
    for e in snap.entities:
        if not (e.valid and e.alive):
            continue
        h = world_to_screen(snap.camera, e.head)
        f = world_to_screen(snap.camera, e.feet)
        if h is None or f is None:
            continue
        half_w = abs(f[1] - h[1]) * aspect / 2
        cx = (h[0] + f[0]) / 2
        boxes.append(EspBox(e.entity_id, cx - half_w, min(h[1], f[1]),
                            cx + half_w, max(h[1], f[1])))
    return boxes
